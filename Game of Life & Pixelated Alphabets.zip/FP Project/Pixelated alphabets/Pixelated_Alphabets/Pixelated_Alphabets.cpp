#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

void initialization(bool**, char*, unsigned int*, bool*, bool*); // determines which pixels need to be colored
void color_initialization(unsigned int*, unsigned int*, unsigned int*); // determines colors in rgb format
void reset(bool**, unsigned int*); // resets pixels' condition
inline bool size_coordinates(bool**, unsigned int*, char*, bool*, bool*); // determines which pixels are colored
void display(bool**, unsigned int*, bool*, bool*, bool*); // displays the given word
void show_error(); // shows an error if input is invalid

inline void a(bool**, unsigned int*); inline void b(bool**, unsigned int*); inline void c(bool**, unsigned int*);
inline void d(bool**, unsigned int*); inline void e(bool**, unsigned int*); inline void f(bool**, unsigned int*);
inline void g(bool**, unsigned int*); inline void h(bool**, unsigned int*); inline void i(bool**, unsigned int*);
inline void j(bool**, unsigned int*); inline void k(bool**, unsigned int*); inline void l(bool**, unsigned int*);
inline void m(bool**, unsigned int*); inline void n(bool**, unsigned int*); inline void o(bool**, unsigned int*);
inline void p(bool**, unsigned int*); inline void q(bool**, unsigned int*); inline void r(bool**, unsigned int*); 
inline void s(bool**, unsigned int*); inline void t(bool**, unsigned int*); inline void u(bool**, unsigned int*); 
inline void v(bool**, unsigned int*); inline void w(bool**, unsigned int*); inline void x(bool**, unsigned int*);
inline void y(bool**, unsigned int*); inline void z(bool**, unsigned int*); // characters' design

int main()
{
	sf::Music app_music;
	if (!app_music.openFromFile("audio\\music.ogg"))
		return 0;
	app_music.setVolume(25);
	app_music.play();
	// initializing the music

	const unsigned int maximum_characters = 100;
	unsigned int pixels_num = 0; // number of horizontal pixels
	bool top = 0, bottom = 0; // whether the top and bottom part are on or not
	bool use_default;

	char* long_word = new char[maximum_characters];;
	bool** pixels = new bool* [13]; // 13 = maximum vertical pixels
	for (int i = 0; i < 13; i++)
		pixels[i] = new bool[maximum_characters * 8](); // 8 = maximum horizontal pixels of one character (m)
	
	initialization(pixels, long_word, &pixels_num, &top, &bottom);
	pixels_num--; // one pixel is extra because of the space between characters

	while (1)
	{
		std::string answer;
		std::cout << "Do you want to use the default version? ";
		std::cin >> answer;
		if (answer == "yes" || answer == "Yes")
		{
			use_default = 1;
			break;
		}
		else if (answer == "no" || answer == "No")
		{
			use_default = 0;
			break;
		}
		else
			show_error();
	}
	// determining whether the user wants to use the default version or not

	display(pixels, &pixels_num, &top, &bottom, &use_default);

	app_music.stop();
	return 1;
}

void initialization(bool** pixels, char* long_word, unsigned int* pixels_num, bool* top, bool* bottom)
{
	bool valid_answer = 0;

	while (!valid_answer)
	{
		valid_answer = 1;
		std::cout << "Enter your word: ";
		std::cin >> long_word;
		for (char* i = long_word; *i != '\0'; i++)
			if (!size_coordinates(pixels, pixels_num, i, top, bottom)) // gets the input again if it's invallid
			{
				show_error();
				reset(pixels, pixels_num);
				valid_answer = 0;
				break;
			}
	}
}

inline void color_initialization(unsigned int* r, unsigned int* g, unsigned int* b)
{
	std::cout << std::endl;

	while (1)
	{
		std::cout << "r: ";
		std::cin >> *r;
		if (*r < 0 || *r > 255)
			show_error();
		else
			break;
	}

	while (1)
	{
		std::cout << "g: ";
		std::cin >> *g;
		if (*g < 0 || *g > 255)
			show_error();
		else
			break;
	}

	while (1)
	{
		std::cout << "b: ";
		std::cin >> *b;
		if (*b < 0 || *b > 255)
			show_error();
		else
			break;
	}
}

void reset(bool** pixels, unsigned int* pixels_num)
{
	for (unsigned int i = 0; i < 13; i++)
		for (unsigned int j = 0; j < *pixels_num; j++)
			pixels[i][j] = 0;

	*pixels_num = 0;
}

void display(bool** pixels, unsigned int* pixels_num, bool* top, bool* bottom, bool* use_default)
{
	const unsigned int Screen_width = 1080;
	unsigned int vertical_pixels = 5 + 4 * *top + 4 * *bottom; // default is five plus 4 for each part

	unsigned int cPXic_r = 185, cPXic_g = 242, cPXic_b = 255; // colored pixels -> ice blue
	unsigned int uPXic_r = 11, uPXic_g = 12, uPXic_b = 12; // uncolored pixels -> 
	unsigned int PXoc_r = 0, PXoc_g = 0, PXoc_b = 0; // pixels' border -> black
	// setting default colors

	if (!*use_default)
	{
		std::cout << "\n  *Enter colors in rgb*  \n\n";
		std::cout << "Enter color of characters";
		color_initialization(&cPXic_r, &cPXic_g, &cPXic_b);
		std::cout << "Enter background color";
		color_initialization(&uPXic_r, &uPXic_g, &uPXic_b);
		std::cout << "Enter pixels' border color";
		color_initialization(&PXoc_r, &PXoc_g, &PXoc_b);
	}
	// getting colors

	float pixels_size = float(Screen_width) / *pixels_num;
	sf::RectangleShape pixel(sf::Vector2f(pixels_size, pixels_size));
	pixel.setOutlineThickness(pixels_size / 7);
	pixel.setOutlineColor(sf::Color(PXoc_r, PXoc_g, PXoc_b));
	// initializing pixels

	unsigned int Screen_height = unsigned int(pixels_size * vertical_pixels);
	// height is based on pixels' size and number of vertical pixels
	sf::RenderWindow Screen(sf::VideoMode(Screen_width, Screen_height), "Pixelated Alphabets", sf::Style::Close);

	unsigned int i = 0; // the start point
	if (!*top)
		i += 4;

	const unsigned int m = i; // for fixing position

	for (i; vertical_pixels > 0; i++, vertical_pixels--)
		for (unsigned int j = 0; j < *pixels_num; j++)
		{
			if (pixels[i][j])
				pixel.setFillColor(sf::Color(cPXic_r, cPXic_g, cPXic_b));
			else
				pixel.setFillColor(sf::Color(uPXic_r, uPXic_g, uPXic_b));

			pixel.setPosition(j * pixels_size, (i - m) * pixels_size);
			Screen.draw(pixel);
		}
	// draws the word

	Screen.display();

	while (Screen.isOpen())
	{
		sf::Event show;
		while (Screen.pollEvent(show))
			if (show.type == sf::Event::Closed || sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
				Screen.close(); // user wants to exit the game
	}
}

void show_error()
{
	const unsigned int Screen_width = 720;
	const unsigned int Screen_height = 240;
	sf::RenderWindow error_screen(sf::VideoMode(Screen_width, Screen_height), "ERROR", sf::Style::None);
	// initializing the error screen

	sf::SoundBuffer error_buffer;
	if (!error_buffer.loadFromFile("audio\\error.wav"))
		return;

	sf::Sound error_sound;
	error_sound.setBuffer(error_buffer);
	error_sound.setVolume(25);
	// initializing the error sound

	sf::Font error_font;
	if (!error_font.loadFromFile("fonts\\error.ttf"))
		return;

	sf::Text error_text;
	error_text.setFont(error_font);
	error_text.setString("ERROR: Unknown data");
	error_text.setCharacterSize(50);
	error_text.setStyle(sf::Text::Bold);
	error_text.setFillColor(sf::Color::Red);
	float errorOrigin_width = error_text.getGlobalBounds().width / 2;
	float errorOrigin_height = error_text.getGlobalBounds().height / 2;
	error_text.setOrigin(errorOrigin_width, errorOrigin_height);
	error_text.setPosition(Screen_width / 2 - 10.f, Screen_height / 2 - 10.f);
	// initializing the error text

	while (error_screen.isOpen())
	{
		error_sound.play();
		error_screen.draw(error_text);
		error_screen.display();

		sf::Clock timer;
		while (timer.getElapsedTime() < sf::milliseconds(250));
		error_sound.stop();

		while (timer.getElapsedTime() < sf::seconds(1.5f));
		error_screen.close();
	}
	// displays the error for a short amount of time
}

inline bool size_coordinates(bool** pixels, unsigned int* pixels_num, char* characters, bool* top, bool* bottom)
{
	switch (*characters)
	{
	case 'a': a(pixels, pixels_num); break;
	case 'b': b(pixels, pixels_num); *top = 1; break;
	case 'c': c(pixels, pixels_num); break;
	case 'd': d(pixels, pixels_num); *top = 1; break;
	case 'e': e(pixels, pixels_num); break;
	case 'f': f(pixels, pixels_num); *top = 1; break;
	case 'g': g(pixels, pixels_num); *bottom = 1; break;
	case 'h': h(pixels, pixels_num); *top = 1; break;
	case 'i': i(pixels, pixels_num); *top = 1; break;
	case 'j': j(pixels, pixels_num); *top = 1; *bottom = 1; break;
	case 'k': k(pixels, pixels_num); *top = 1; break;
	case 'l': l(pixels, pixels_num); *top = 1; break;
	case 'm': m(pixels, pixels_num); break;
	case 'n': n(pixels, pixels_num); break;
	case 'o': o(pixels, pixels_num); break;
	case 'p': p(pixels, pixels_num); *bottom = 1; break;
	case 'q': q(pixels, pixels_num); *bottom = 1; break;
	case 'r': r(pixels, pixels_num); break;
	case 's': s(pixels, pixels_num); break;
	case 't': t(pixels, pixels_num); *top = 1; break;
	case 'u': u(pixels, pixels_num); break;
	case 'v': v(pixels, pixels_num); break;
	case 'w': w(pixels, pixels_num); break;
	case 'x': x(pixels, pixels_num); break;
	case 'y': y(pixels, pixels_num); *bottom = 1; break;
	case 'z': z(pixels, pixels_num); break;
	default: return 0; break; // returns false if the character is invalid
	}
	return 1;
}

inline void a(bool** pixels, unsigned int* pixels_num)
{
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 4] = 1;
	*pixels_num += 6;
}
inline void b(bool** pixels, unsigned int* pixels_num)
{
	pixels[0][*pixels_num] = 1;
	pixels[1][*pixels_num] = 1;
	pixels[2][*pixels_num] = 1;
	pixels[3][*pixels_num] = 1;
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void c(bool** pixels, unsigned int* pixels_num)
{
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void d(bool** pixels, unsigned int* pixels_num)
{
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[0][*pixels_num + 3] = 1;
	pixels[1][*pixels_num + 3] = 1;
	pixels[2][*pixels_num + 3] = 1;
	pixels[3][*pixels_num + 3] = 1;
	pixels[4][*pixels_num + 3] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void e(bool** pixels, unsigned int* pixels_num)
{
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[6][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[6][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void f(bool** pixels, unsigned int* pixels_num)
{
	pixels[5][*pixels_num] = 1;
	pixels[1][*pixels_num + 1] = 1;
	pixels[2][*pixels_num + 1] = 1;
	pixels[3][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[5][*pixels_num + 1] = 1;
	pixels[6][*pixels_num + 1] = 1;
	pixels[7][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[0][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 2] = 1;
	pixels[1][*pixels_num + 3] = 1;
	pixels[2][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void g(bool** pixels, unsigned int* pixels_num)
{
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[11][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[12][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[12][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	pixels[9][*pixels_num + 3] = 1;
	pixels[10][*pixels_num + 3] = 1;
	pixels[11][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void h(bool** pixels, unsigned int* pixels_num)
{
	pixels[0][*pixels_num] = 1;
	pixels[1][*pixels_num] = 1;
	pixels[2][*pixels_num] = 1;
	pixels[3][*pixels_num] = 1;
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void i(bool** pixels, unsigned int* pixels_num)
{
	pixels[2][*pixels_num] = 1;
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	*pixels_num += 2;
}
inline void j(bool** pixels, unsigned int* pixels_num)
{
	pixels[11][*pixels_num] = 1;
	pixels[12][*pixels_num + 1] = 1;
	pixels[12][*pixels_num + 2] = 1;
	pixels[2][*pixels_num + 3] = 1;
	pixels[4][*pixels_num + 3] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	pixels[9][*pixels_num + 3] = 1;
	pixels[10][*pixels_num + 3] = 1;
	pixels[11][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void k(bool** pixels, unsigned int* pixels_num)
{
	pixels[0][*pixels_num] = 1;
	pixels[1][*pixels_num] = 1;
	pixels[2][*pixels_num] = 1;
	pixels[3][*pixels_num] = 1;
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[6][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 2] = 1;
	pixels[7][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void l(bool** pixels, unsigned int* pixels_num)
{
	pixels[0][*pixels_num] = 1;
	pixels[1][*pixels_num] = 1;
	pixels[2][*pixels_num] = 1;
	pixels[3][*pixels_num] = 1;
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[7][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void m(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[5][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 6] = 1;
	pixels[5][*pixels_num + 4] = 1;
	pixels[4][*pixels_num + 5] = 1;
	pixels[5][*pixels_num + 6] = 1;
	pixels[6][*pixels_num + 6] = 1;
	pixels[7][*pixels_num + 6] = 1;
	pixels[8][*pixels_num + 6] = 1;
	*pixels_num += 8;
}
inline void n(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void o(bool** pixels, unsigned int* pixels_num)
{
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void p(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[9][*pixels_num] = 1;
	pixels[10][*pixels_num] = 1;
	pixels[11][*pixels_num] = 1;
	pixels[12][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void q(bool** pixels, unsigned int* pixels_num)
{
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[4][*pixels_num + 3] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	pixels[9][*pixels_num + 3] = 1;
	pixels[10][*pixels_num + 3] = 1;
	pixels[11][*pixels_num + 3] = 1;
	pixels[12][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void r(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[5][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void s(bool** pixels, unsigned int* pixels_num)
{
	pixels[5][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[6][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[6][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[4][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void t(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[2][*pixels_num + 1] = 1;
	pixels[3][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[5][*pixels_num + 1] = 1;
	pixels[6][*pixels_num + 1] = 1;
	pixels[7][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 4] = 1;
	*pixels_num += 6;
}
inline void u(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[4][*pixels_num + 3] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void v(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num + 1] = 1;
	pixels[7][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[4][*pixels_num + 4] = 1;
	pixels[5][*pixels_num + 4] = 1;
	*pixels_num += 6;
}
inline void w(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[6][*pixels_num + 2] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	pixels[4][*pixels_num + 4] = 1;
	pixels[5][*pixels_num + 4] = 1;
	pixels[6][*pixels_num + 4] = 1;
	*pixels_num += 6;
}
inline void x(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[5][*pixels_num + 1] = 1;
	pixels[7][*pixels_num + 1] = 1;
	pixels[6][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[4][*pixels_num + 4] = 1;
	pixels[8][*pixels_num + 4] = 1;
	*pixels_num += 6;
}
inline void y(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[5][*pixels_num] = 1;
	pixels[6][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[11][*pixels_num] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[12][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[12][*pixels_num + 2] = 1;
	pixels[4][*pixels_num + 3] = 1;
	pixels[5][*pixels_num + 3] = 1;
	pixels[6][*pixels_num + 3] = 1;
	pixels[7][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	pixels[9][*pixels_num + 3] = 1;
	pixels[10][*pixels_num + 3] = 1;
	pixels[11][*pixels_num + 3] = 1;
	*pixels_num += 5;
}
inline void z(bool** pixels, unsigned int* pixels_num)
{
	pixels[4][*pixels_num] = 1;
	pixels[7][*pixels_num] = 1;
	pixels[8][*pixels_num] = 1;
	pixels[4][*pixels_num + 1] = 1;
	pixels[6][*pixels_num + 1] = 1;
	pixels[8][*pixels_num + 1] = 1;
	pixels[4][*pixels_num + 2] = 1;
	pixels[5][*pixels_num + 2] = 1;
	pixels[8][*pixels_num + 2] = 1;
	pixels[4][*pixels_num + 3] = 1;
	pixels[8][*pixels_num + 3] = 1;
	*pixels_num += 5;
}