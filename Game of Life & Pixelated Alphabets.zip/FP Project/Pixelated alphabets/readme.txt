1. The project folder contains two folders fonts and audio which contain the font and music that are used in the program.

2. For the program to work properly you need to copy the "sfml" folder and paste it to the project folder "Pixelated_Alphabets".

3. At first you enter the word (must consist of less than 100 characters) you want to be shown graphically then you'll be asked if you want to use the default version:
    a) "Yes/yes" the default version
    b) "No/no" you can choose the colors yourself

4. Check out the "model" folder for how the characters will look like

5. For more information please read the report.