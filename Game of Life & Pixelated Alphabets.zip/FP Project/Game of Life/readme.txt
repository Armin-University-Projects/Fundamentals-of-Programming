1. The project folder contains two folders fonts and audio which contain the fonts and musics that are used in the program.

2. For the program to work properly you need to copy the "sfml" folder and paste it to the projcect folder "Game_of_Life".

3. First you'll be asked if you want to use the default version (what was requested in the assignment), you have two options: 
    a) "Yes/yes"
    b) "No/no", then you can choose the board size, colors, number of levels, and the delay between each level.

4. You can start the game either by clicking on the start button or pressing Enter/Space

5. You can always exit the game either by clicking the eXit button or pressing Escape

6. For more information please read the report.