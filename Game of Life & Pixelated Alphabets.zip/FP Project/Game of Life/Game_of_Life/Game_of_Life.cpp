#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

void initialization(bool**, int*); // determines the cells' condition
inline void color_initialization(unsigned int*, unsigned int*, unsigned int*); // determines colors in rgb format
void iterator(bool**, bool**, const int*); // iterates through the board
inline bool check(bool**, const int*, const int*, const int*); // checks cells and their neighbors' condition
void display(bool**, const int*, bool*); // displays the game screen
void show_error(); // shows an error if input is invalid

int main()
{
    bool use_default;
    int Board_size = 100;
    // setting defaults

    while (1)
    {
        std::string answer;
        std::cout << "Do you want to use default version? ";
        std::cin >> answer;
        if (answer == "Yes" || answer == "yes")
        {
            use_default = 1;
            break;
        }
        else if (answer == "no" || answer == "No")
        {
            use_default = 0;
            break;
        }
        else
            show_error();
    }
    // determining whether the user wants to use the default version or not

    while (!use_default)
    {
        std::cout << "Enter the number of cells you want at each side: ";
        std::cin >> Board_size;
        if (Board_size <= 0)
            show_error();
        else
            break;
    }
    // getting the board size

    bool** Board = new bool* [Board_size];

    initialization(Board, &Board_size);
    display(Board, &Board_size, &use_default);
    
    return 1;
}

void initialization(bool** Board, int* Board_size)
{
    srand(unsigned int(time(NULL)));

    int alive_cells = 0;
    int remaining_cells = *Board_size * *Board_size;
    
    const int minimum_alive_cells = *Board_size;
    const int maximum_alive_cells = *Board_size * *Board_size / 2;
    // setting limits

    for (int i = 0; i < *Board_size; i++)
    {
        Board[i] = new bool[*Board_size]();
        for (int j = 0; j < *Board_size; j++)
        {
            if (alive_cells + remaining_cells < minimum_alive_cells) // possible alive cells are less than minimum
                Board[i][j] = 1;
            else if (alive_cells <= maximum_alive_cells) // within the range
                Board[i][j] = rand() % 2;
            if (Board[i][j] == 1)
                alive_cells++;
            remaining_cells--;
        }
    }
    // randomizes the cells' condition
}

inline void color_initialization(unsigned int* r, unsigned int* g, unsigned int* b)
{
    std::cout << std::endl;

    while (1)
    {
        std::cout << "r: ";
        std::cin >> *r;
        if (*r < 0 || *r > 255)
            show_error();
        else
            break;
    }

    while (1)
    {
        std::cout << "g: ";
        std::cin >> *g;
        if (*g < 0 || *g > 255)
            show_error();
        else
            break;
    }

    while (1)
    {
        std::cout << "b: ";
        std::cin >> *b;
        if (*b < 0 || *b > 255)
            show_error();
        else
            break;
    }
}

void iterator(bool** Board, bool** cells_new_condition, const int* Board_size)
{
    for (int i = 0; i < *Board_size; i++)
        for (int j = 0; j < *Board_size; j++)
            cells_new_condition[i][j] = check(Board, Board_size, &i, &j);
    // determines cells new condition

    for (int i = 0; i < *Board_size; i++)
        for (int j = 0; j < *Board_size; j++)
            Board[i][j] = cells_new_condition[i][j];
    // changes cells' condition to new ones
}

inline bool check(bool** Board, const int* Board_size, const int* row, const int* column)
{
    unsigned int alive_neighbers = 0;

    for (int i = *row - 1; i <= *row + 1 && i < *Board_size; i++)
    {
        if (i < 0)
            continue;
        for (int j = *column - 1; j <= *column + 1 && j < *Board_size; j++)
            if (j < 0)
                continue;
            else if (Board[i][j])
                alive_neighbers++;
    }
    // counts the number of the cell's alive neighbors including the cell itself

    if (Board[*row][*column])
    {
        if (alive_neighbers >= 3 && alive_neighbers <= 4)
            return 1;
    }
    else if (alive_neighbers == 3)
        return 1;

    return 0;
    // determines the cell's new condition
}

void display(bool** Board, const int* Board_size, bool* use_default)
{
    bool** cells_condition = new bool* [*Board_size];
    for (int i = 0; i < *Board_size; i++)
        cells_condition[i] = new bool[*Board_size];
    // new board for keeping cells condition

    const unsigned int Screen_size = 720;
    unsigned int extra_width = 25;
    unsigned int extra_height = 150;
    unsigned int number_of_levels = 10;
    // setting default sizes and level numbers

    unsigned int aPXic_r = 0, aPXic_g = 23, aPXic_b = 45; // alive cells' inner color -> dark blue
    unsigned int dPXic_r = 185, dPXic_g = 242, dPXic_b = 255; // dead cells inner color -> ice blue
    unsigned int PXoc_r = 0, PXoc_g = 0, PXoc_b = 0; // cells' border color -> black
    // setting default colors

    sf::Color Screen_color = sf::Color::Cyan;

    sf::Time delay_time = sf::milliseconds(1000);

    if (!*use_default)
    {
        std::cout << "\n    *Enter colors in rgb*    \n\n";
        std::cout << "Enter alive cells' inner color";
        color_initialization(&aPXic_r, &aPXic_g, &aPXic_b);
        std::cout << "Enter dead cells' inner color";
        color_initialization(&dPXic_r, &dPXic_g, &dPXic_b);
        std::cout << "Enter cells' border color";
        color_initialization(&PXoc_r, &PXoc_g, &PXoc_b);
        // getting colors

        while (1)
        {
            std::cout << "Enter the number of levels you want to be shown: ";
            std::cin >> number_of_levels;
            if (number_of_levels <= 0)
                show_error();
            else
                break;
        }
        // getting number of levels

        while (1)
        {
            int dt;
            std::cout << "Enter the amount of delay between levels (in milliseconds): ";
            std::cin >> dt;
            if (dt < 0)
                show_error();
            else
            {
                delay_time = sf::milliseconds(dt);
                break;
            }
        }
        // getting delay time
    }

    sf::RenderWindow Screen(sf::VideoMode(Screen_size + extra_width * 2, Screen_size + extra_height), "Game of Life", sf::Style::Close);
    Screen.setFramerateLimit(60);
    // initializing the game screen

    float Pixel_size = float(Screen_size) / *Board_size;
    sf::RectangleShape pixel(sf::Vector2f(Pixel_size, Pixel_size));
    pixel.setOutlineThickness(Pixel_size / 7);
    pixel.setOutlineColor(sf::Color(PXoc_r, PXoc_g, PXoc_b));
    // initializing the cells' properties

    sf::Font button_font;
    if (!button_font.loadFromFile("fonts\\buttons.ttf"))
        return;

    sf::Text button;
    button.setString("Start");
    button.setFont(button_font);
    button.setFillColor(sf::Color::Black);
    button.setCharacterSize(extra_height / 4);
    float buttonOrigin_width = button.getLocalBounds().width / 2;
    float buttonOrigin_height = button.getLocalBounds().height / 2;
    button.setOrigin(buttonOrigin_width, buttonOrigin_height);
    button.setPosition(float(Screen_size) / 2 + extra_width, Screen_size + float(extra_height) / 2);
    // initializing the start button properties

    sf::Music game_music;
    if (!game_music.openFromFile("audio\\game music.ogg"))
        return;

    game_music.setLoop(true);
    game_music.setVolume(75);
    // initializing the game music

    sf::Music game_ending;
    if (!game_ending.openFromFile("audio\\game ending.ogg"))
        return;

    game_ending.setLoop(true);
    game_ending.setVolume(75);
    game_ending.setPlayingOffset(sf::milliseconds(750));
    // initializing the ending music

    while (Screen.isOpen())
    {
        sf::Event show;
        while (Screen.pollEvent(show))
            if (show.type == sf::Event::Closed || sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
                Screen.close(); // user wants to exit the game

        Screen.clear(Screen_color);

        for (int i = 0; i < *Board_size; i++)
            for (int j = 0; j < *Board_size; j++)
            {
                if (Board[i][j])
                    pixel.setFillColor(sf::Color(aPXic_r, aPXic_g, aPXic_b));
                else
                    pixel.setFillColor(sf::Color(dPXic_r, dPXic_g, dPXic_b));

                pixel.setPosition(j * Pixel_size + extra_width, i * Pixel_size + extra_width);
                Screen.draw(pixel);
            }
        // draws cells

        Screen.draw(button);
        Screen.display();
        // displaying the level zero
        
        // checking if the user starts by clicking on start button or by pressing Space/Enter
        if ((sf::Mouse::isButtonPressed(sf::Mouse::Left) && 
            sf::Mouse::getPosition(Screen).x <= button.getPosition().x + buttonOrigin_width &&
            sf::Mouse::getPosition(Screen).x >= button.getPosition().x - buttonOrigin_width &&
            sf::Mouse::getPosition(Screen).y <= button.getPosition().y + buttonOrigin_height &&
            sf::Mouse::getPosition(Screen).y >= button.getPosition().y - buttonOrigin_height) ||
            sf::Keyboard::isKeyPressed(sf::Keyboard::Enter) || sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
        {
            game_music.play();

            while (number_of_levels > 0)
            {
                while (Screen.pollEvent(show))
                    if (show.type == sf::Event::Closed || sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
                    {
                        Screen.close();
                        game_music.stop();
                        game_ending.stop();
                    }
                // ending the game manually

                iterator(Board, cells_condition, Board_size);

                Screen.clear(Screen_color);

                for (int i = 0; i < *Board_size; i++)
                    for (int j = 0; j < *Board_size; j++)
                    {
                        if (Board[i][j])
                            pixel.setFillColor(sf::Color(aPXic_r, aPXic_g, aPXic_b));
                        else
                            pixel.setFillColor(sf::Color(dPXic_r, dPXic_g, dPXic_b));

                        pixel.setPosition(j * Pixel_size + extra_width, i * Pixel_size + extra_width);
                        Screen.draw(pixel);
                    }
                // draws cells

                Screen.display();

                sf::Clock timer;
                while (timer.getElapsedTime() < delay_time);
                // delay between levels

                number_of_levels--;
            }
            // going through the game

            button.setString("Life is Over!");
            button.setOrigin(button.getLocalBounds().width / 2, button.getLocalBounds().height / 2);
            button.setPosition(float(Screen_size) / 2 + extra_width, Screen_size + float(extra_height) / 2);
            game_music.stop();
            game_ending.play();
            Screen.draw(button);
            // the game's aftermath
        }
    }
    // displays the game
}

void show_error()
{
    const unsigned int Screen_width = 720;
    const unsigned int Screen_height = 240;
    sf::RenderWindow error_screen(sf::VideoMode(Screen_width, Screen_height), "ERROR", sf::Style::None);
    // initializing the error screen

    sf::SoundBuffer error_buffer;
    if (!error_buffer.loadFromFile("audio\\error.wav"))
        return;

    sf::Sound error_sound;
    error_sound.setBuffer(error_buffer);
    error_sound.setVolume(25);
    // initializing the error sound

    sf::Font error_font;
    if (!error_font.loadFromFile("fonts\\error.ttf"))
        return;

    sf::Text error_text;
    error_text.setFont(error_font);
    error_text.setString("ERROR: Unknown data");
    error_text.setCharacterSize(50);
    error_text.setStyle(sf::Text::Bold);
    error_text.setFillColor(sf::Color::Red);
    float errorOrigin_width = error_text.getGlobalBounds().width / 2;
    float errorOrigin_height = error_text.getGlobalBounds().height / 2;
    error_text.setOrigin(errorOrigin_width, errorOrigin_height);
    error_text.setPosition(Screen_width / 2 - 10.f, Screen_height / 2 - 10.f);
    // initializing the error text

    while (error_screen.isOpen())
    {
        error_sound.play();
        error_screen.draw(error_text);
        error_screen.display();

        sf::Clock timer;
        while (timer.getElapsedTime() < sf::milliseconds(250));
        error_sound.stop();

        while (timer.getElapsedTime() < sf::seconds(1.5f));
        error_screen.close();
    }
    // displays the error for a short amount of time
}